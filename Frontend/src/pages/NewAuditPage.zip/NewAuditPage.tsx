import React, { useState, useEffect } from 'react';
import {
  Typography, Box, TextField, Button, Card, CardContent,
  FormControl, InputLabel, Select, MenuItem, Alert, CircularProgress,
  Stepper, Step, StepLabel, RadioGroup, FormControlLabel, Radio,
  IconButton, Chip, Divider, FormHelperText, Autocomplete,
} from '@mui/material';
import { AddPhotoAlternate, Delete, Save, Publish, ArrowBack, ArrowForward, CloudUpload } from '@mui/icons-material';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { format } from 'date-fns';
import { useAuth } from '../contexts/AuthContext';
import { Department, Question, User, AuditPlan } from '../types';
import { useSearchParams } from 'react-router-dom';

// Mock Data
const mockDepartments: Department[] = [
  { id: 1, name: 'Üretim Hattı A', description: 'Ana üretim hattı', created_at: '2023-01-01' },
  { id: 2, name: 'Depo Alanı B', description: 'Malzeme depolama alanı', created_at: '2023-01-01' },
  { id: 3, name: 'Montaj Bölümü', description: 'Ürün montaj alanı', created_at: '2023-01-01' },
];

const mockUsers: User[] = [
  { id: 1, name: 'Ali Veli', email: 'ali@5s.com', role: 'denetci', is_active: true, created_at: '2023-01-01' },
  { id: 2, name: 'Ayşe Yılmaz', email: 'ayse@5s.com', role: 'denetci', is_active: true, created_at: '2023-01-01' },
  { id: 3, name: 'Mehmet Kaya', email: 'mehmet@5s.com', role: 'bolum_sorumlusu', is_active: true, created_at: '2023-01-01' },
];

const mockAreas = [
  'Üretim Alanı 1',
  'Üretim Alanı 2', 
  'Depo Alanı',
  'Montaj Alanı',
  'Ofis Alanı',
  'Makine Atölyesi',
  'Kalite Kontrol',
  'Ambar',
];

const mockQuestionsData: Question[] = [
  { id: 1, category: '1S - Seiri', text: 'Çalışma alanında sadece gerekli eşyalar mı bulunuyor?', order: 1 },
  { id: 2, category: '1S - Seiri', text: 'Gereksiz malzemeler temizlenmiş mi?', order: 2 },
  { id: 3, category: '2S - Seiton', text: 'Her şeyin belirli bir yeri var mı?', order: 3 },
  { id: 4, category: '2S - Seiton', text: 'Eşyalar kolayca bulunup yerine konulabiliyor mu?', order: 4 },
  { id: 5, category: '3S - Seiso', text: 'Çalışma alanı ve ekipmanlar temiz mi?', order: 5 },
  { id: 6, category: '3S - Seiso', text: 'Temizlik standartları belirlenmiş mi?', order: 6 },
  { id: 7, category: '4S - Seiketsu', text: 'İlk 3S için standartlar oluşturulmuş ve uygulanıyor mu?', order: 7 },
  { id: 8, category: '4S - Seiketsu', text: 'Görsel kontroller (etiketler, işaretler) mevcut mu?', order: 8 },
  { id: 9, category: '5S - Shitsuke', text: '5S kurallarına uyum düzenli olarak denetleniyor mu?', order: 9 },
  { id: 10, category: '5S - Shitsuke', text: 'Çalışanlar 5S konusunda eğitimli ve bilinçli mi?', order: 10 },
];

const steps = ['Denetim Bilgileri', 'Soru Cevaplama', 'Özet ve Kaydet'];

const schema = yup.object({
  department_id: yup.number().required('Bölüm seçimi zorunludur').min(1, 'Bölüm seçimi zorunludur'),
  audit_date: yup.string().required('Denetim tarihi zorunludur'),
  area: yup.string().required('Alan seçimi zorunludur'),
  auditor_id: yup.number().required('Denetleyen seçimi zorunludur').min(1, 'Denetleyen seçimi zorunludur'),
  responsible_user_id: yup.number().required('Sorumlu seçimi zorunludur').min(1, 'Sorumlu seçimi zorunludur'),
  questions: yup.array().of(
    yup.object({
      question_id: yup.number().required(),
      category: yup.string().required(),
      text: yup.string().required(),
      score: yup.string().required('Lütfen bir değerlendirme seçin'),
      images: yup.array().of(yup.string()).optional(),
      actions: yup.array().of(
        yup.object({
          identified_non_conformity: yup.string().required('Uygunsuzluk tespiti zorunludur'),
          proposed_activity: yup.string().required('Önerilen faaliyet zorunludur'),
          planned_activity: yup.string().required('Planlanan faaliyet zorunludur'),
          responsible_user_id: yup.number().required(),
          target_date: yup.string().required('Hedef tarih zorunludur'),
          priority: yup.string().required(),
          non_conformity_visual: yup.string().optional(),
        })
      ).optional(),
    })
  ).required(),
});

interface ActionFormData {
  identified_non_conformity: string;
  proposed_activity: string;
  planned_activity: string;
  responsible_user_id: number;
  target_date: string;
  priority: 'Düşük' | 'Orta' | 'Yüksek';
  non_conformity_visual?: string;
}

interface QuestionFormData {
  question_id: number;
  category: string;
  text: string;
  score: 'dusuk' | 'orta' | 'yuksek' | '';
  images?: string[];
  actions?: ActionFormData[];
}

interface AuditFormData {
  department_id: number;
  audit_date: string;
  area: string;
  auditor_id: number;
  responsible_user_id: number;
  questions: QuestionFormData[];
}

const NewAuditPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const planId = searchParams.get('planId');
  const [activeStep, setActiveStep] = useState(0);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [plan, setPlan] = useState<AuditPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const {
    control,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
    setValue,
  } = useForm<AuditFormData>({
    resolver: yupResolver(schema) as any,
    defaultValues: {
      department_id: 1,
      audit_date: format(new Date(), 'yyyy-MM-dd'),
      area: '',
      auditor_id: user?.id || 1,
      responsible_user_id: user?.id || 1,
      questions: mockQuestionsData.map(q => ({
        question_id: q.id,
        category: q.category,
        text: q.text,
        score: '',
        images: [],
        actions: [],
      })),
    },
  });

  const { fields: questionFields, update: updateQuestion } = useFieldArray({
    control,
    name: 'questions',
  });

  useEffect(() => {
    const fetchInitialData = async () => {
      setLoading(true);
      try {
        setDepartments(mockDepartments);
        setUsers(mockUsers);
        
        // Eğer planId varsa, plan bilgilerini yükle
        if (planId) {
          // Mock plan data
          const mockPlan: AuditPlan = {
            id: parseInt(planId),
            name: 'Üretim Hattı A - Ocak Denetimi',
            department_id: 1,
            department_name: 'Üretim Hattı A',
            area: 'Üretim Alanı 1',
            auditor_id: user?.id || 1,
            auditor_name: user?.name || 'Admin User',
            planned_date: format(new Date(), 'yyyy-MM-dd'),
            status: 'in_progress',
            created_at: new Date().toISOString(),
          };
          setPlan(mockPlan);
          
          // Plan bilgilerini form'a yükle
          setValue('department_id', mockPlan.department_id);
          setValue('area', mockPlan.area);
          setValue('auditor_id', mockPlan.auditor_id);
          setValue('audit_date', mockPlan.planned_date);
          
          // İlk adımı atla, direkt soru cevaplama sayfasına git
          setActiveStep(1);
        }
      } catch (err: any) {
        setError('Veriler yüklenirken hata oluştu: ' + err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchInitialData();
  }, [planId, user, setValue]);

  const handleAddAction = (questionIndex: number) => {
    const currentActions = questionFields[questionIndex].actions || [];
    updateQuestion(questionIndex, {
      ...questionFields[questionIndex],
      actions: [
        ...currentActions,
        {
          identified_non_conformity: '',
          proposed_activity: '',
          planned_activity: '',
          responsible_user_id: user?.id || 0,
          target_date: format(new Date(), 'yyyy-MM-dd'),
          priority: 'Orta',
          non_conformity_visual: '',
        },
      ],
    });
  };

  // Auto-add action when score is 'dusuk' or 'orta'
  useEffect(() => {
    const subscription = watch((value, { name, type }) => {
      if (name && name.includes('.score') && type === 'change') {
        const questionIndex = parseInt(name.split('.')[1]);
        const score = value.questions?.[questionIndex]?.score;
        
        if ((score === 'dusuk' || score === 'orta')) {
          const currentActions = questionFields[questionIndex]?.actions || [];
          if (currentActions.length === 0) {
            handleAddAction(questionIndex);
          }
        }
      }
    });
    return () => subscription.unsubscribe();
  }, [watch, questionFields]);

  const handleNext = async () => {
    if (activeStep === 0) {
      // Basic validation for step 1
      try {
        await handleSubmit(() => {}, () => {})();
      } catch {
        return;
      }
    } else if (activeStep === 1) {
      const questionErrors = errors.questions;
      if (questionErrors && Object.keys(questionErrors).length > 0) {
        setError('Lütfen tüm soruları yanıtlayın ve aksiyon formlarını doldurun.');
        return;
      }
      setError(null);
    }
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const calculateScore = () => {
    let totalScore = 0;
    let maxScore = 0;
    questionFields.forEach(q => {
      maxScore += 5;
      switch (q.score) {
        case 'yuksek':
          totalScore += 5;
          break;
        case 'orta':
          totalScore += 3;
          break;
        case 'dusuk':
          totalScore += 1;
          break;
        default:
          break;
      }
    });
    const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0;
    return { totalScore, maxScore, percentage };
  };

  const get5SLevel = (percentage: number) => {
    if (percentage >= 90) return '5S - Mükemmel';
    if (percentage >= 80) return '4S - İyi';
    if (percentage >= 70) return '3S - Orta';
    if (percentage >= 60) return '2S - Geliştirilmeli';
    if (percentage >= 50) return '1S - Zayıf';
    return 'Kritik Seviye';
  };

  const handleMultipleImageUpload = (questionIndex: number, files: FileList) => {
    const currentImages = questionFields[questionIndex].images || [];
    const newImages: string[] = [];
    
    Array.from(files).forEach((file, index) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newImages.push(reader.result as string);
        if (newImages.length === files.length) {
          setValue(`questions.${questionIndex}.images`, [...currentImages, ...newImages]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (questionIndex: number, imageIndex: number) => {
    const currentImages = questionFields[questionIndex].images || [];
    const updatedImages = currentImages.filter((_, idx) => idx !== imageIndex);
    setValue(`questions.${questionIndex}.images`, updatedImages);
  };

  const handleActionImageUpload = (questionIndex: number, actionIndex: number, file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setValue(`questions.${questionIndex}.actions.${actionIndex}.non_conformity_visual`, reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveAction = (questionIndex: number, actionIndex: number) => {
    const currentActions = questionFields[questionIndex].actions || [];
    const updatedActions = currentActions.filter((_, idx) => idx !== actionIndex);
    updateQuestion(questionIndex, {
      ...questionFields[questionIndex],
      actions: updatedActions,
    });
  };

  const onSubmit = async (data: AuditFormData, status: 'draft' | 'published') => {
    setLoading(true);
    setError(null);
    try {
      console.log('Submitting Audit:', { ...data, status });
      alert(`Denetim başarıyla ${status === 'published' ? 'yayınlandı' : 'taslak olarak kaydedildi'}!`);
      reset();
      setActiveStep(0);
    } catch (err: any) {
      setError('Denetim kaydedilirken hata oluştu: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Card sx={{ p: 2 }}>
            <CardContent sx={{ p: 0 }}>
              {/* First Row - 3 Fields */}
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 2 }}>
                <Box sx={{ flex: '1 1 250px', minWidth: 0 }}>
                  <Controller
                    name="department_id"
                    control={control}
                    render={({ field }) => (
                      <FormControl fullWidth error={!!errors.department_id} size="small">
                        <InputLabel>Bölüm</InputLabel>
                        <Select {...field} label="Bölüm">
                          {departments.map((dept) => (
                            <MenuItem key={dept.id} value={dept.id}>
                              {dept.name}
                            </MenuItem>
                          ))}
                        </Select>
                        {errors.department_id && <FormHelperText>{errors.department_id.message}</FormHelperText>}
                      </FormControl>
                    )}
                  />
                </Box>
                <Box sx={{ flex: '1 1 250px', minWidth: 0 }}>
                  <Controller
                    name="audit_date"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Denetim Tarihi"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                        error={!!errors.audit_date}
                        helperText={errors.audit_date?.message}
                      />
                    )}
                  />
                </Box>
                <Box sx={{ flex: '1 1 250px', minWidth: 0 }}>
                  <Controller
                    name="area"
                    control={control}
                    render={({ field: { onChange, value, ...field } }) => (
                      <Autocomplete
                        {...field}
                        value={value || ''}
                        onChange={(_, newValue) => onChange(newValue || '')}
                        options={mockAreas}
                        freeSolo
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Denetim Alanı"
                            fullWidth
                            size="small"
                            error={!!errors.area}
                            helperText={errors.area?.message}
                          />
                        )}
                      />
                    )}
                  />
                </Box>
              </Box>
              
              {/* Second Row - 2 Fields */}
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                <Box sx={{ flex: '1 1 300px', minWidth: 0 }}>
                  <Controller
                    name="auditor_id"
                    control={control}
                    render={({ field }) => (
                      <FormControl fullWidth error={!!errors.auditor_id} size="small">
                        <InputLabel>Denetleyen</InputLabel>
                        <Select {...field} label="Denetleyen">
                          {users.filter(u => u.role === 'denetci' || u.role === 'admin').map((user) => (
                            <MenuItem key={user.id} value={user.id}>
                              {user.name}
                            </MenuItem>
                          ))}
                        </Select>
                        {errors.auditor_id && <FormHelperText>{errors.auditor_id.message}</FormHelperText>}
                      </FormControl>
                    )}
                  />
                </Box>
                <Box sx={{ flex: '1 1 300px', minWidth: 0 }}>
                  <Controller
                    name="responsible_user_id"
                    control={control}
                    render={({ field }) => (
                      <FormControl fullWidth error={!!errors.responsible_user_id} size="small">
                        <InputLabel>Sorumlu</InputLabel>
                        <Select {...field} label="Sorumlu">
                          {users.map((user) => (
                            <MenuItem key={user.id} value={user.id}>
                              {user.name}
                            </MenuItem>
                          ))}
                        </Select>
                        {errors.responsible_user_id && <FormHelperText>{errors.responsible_user_id.message}</FormHelperText>}
                      </FormControl>
                    )}
                  />
                </Box>
              </Box>
            </CardContent>
          </Card>
        );

      case 1:
        // Soruları kategorilere göre grupla
        const questionsByCategory = questionFields.reduce((acc, question, index) => {
          const category = question.category || 'Diğer';
          if (!acc[category]) {
            acc[category] = [];
          }
          acc[category].push({ question, index });
          return acc;
        }, {} as Record<string, Array<{ question: any; index: number }>>);

        // 5S sırasına göre kategorileri sırala
        const categoryOrder = ['1S - Seiri', '2S - Seiton', '3S - Seiso', '4S - Seiketsu', '5S - Shitsuke'];
        const sortedCategories = Object.keys(questionsByCategory).sort((a, b) => {
          const aIndex = categoryOrder.indexOf(a);
          const bIndex = categoryOrder.indexOf(b);
          if (aIndex === -1 && bIndex === -1) return 0;
          if (aIndex === -1) return 1;
          if (bIndex === -1) return -1;
          return aIndex - bIndex;
        });

        // Kategori renkleri
        const getCategoryColor = (category: string) => {
          if (category.includes('1S')) return { bg: '#fee2e2', border: '#ef4444', text: '#dc2626' };
          if (category.includes('2S')) return { bg: '#fef3c7', border: '#f59e0b', text: '#d97706' };
          if (category.includes('3S')) return { bg: '#dbeafe', border: '#3b82f6', text: '#2563eb' };
          if (category.includes('4S')) return { bg: '#e0e7ff', border: '#6366f1', text: '#4f46e5' };
          if (category.includes('5S')) return { bg: '#d1fae5', border: '#10b981', text: '#059669' };
          return { bg: '#f3f4f6', border: '#6b7280', text: '#374151' };
        };

        const getCategoryDescription = (category: string) => {
          if (category.includes('1S')) return 'Ayırt etme ve gereksizleri kaldırma';
          if (category.includes('2S')) return 'Düzenleme ve yerleştirme';
          if (category.includes('3S')) return 'Temizlik ve bakım';
          if (category.includes('4S')) return 'Standartlaştırma';
          if (category.includes('5S')) return 'Sürdürme ve disiplin';
          return '';
        };

        return (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {sortedCategories.map((category) => {
              const categoryColor = getCategoryColor(category);
              const categoryQuestions = questionsByCategory[category];
              const answeredCount = categoryQuestions.filter(
                ({ question, index }) => watch(`questions.${index}.score`) !== ''
              ).length;
              const totalCount = categoryQuestions.length;

              return (
                <Card 
                  key={category} 
                  sx={{ 
                    border: `2px solid ${categoryColor.border}`,
                    borderRadius: 2,
                    overflow: 'hidden',
                  }}
                >
                  {/* Kategori Başlığı */}
                  <Box 
                    sx={{ 
                      bgcolor: categoryColor.bg,
                      px: 1.5,
                      py: 1,
                      borderBottom: `1px solid ${categoryColor.border}`,
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography 
                        variant="h6" 
                        sx={{ 
                          fontSize: '0.9rem', 
                          fontWeight: 600, 
                          color: categoryColor.text,
                        }}
                      >
                        {category}
                      </Typography>
                      <Chip
                        label={`${answeredCount}/${totalCount}`}
                        size="small"
                        sx={{
                          bgcolor: 'white',
                          color: categoryColor.text,
                          fontWeight: 600,
                          fontSize: '0.65rem',
                          height: 20,
                        }}
                      />
                    </Box>
                  </Box>

                  {/* Kategori Soruları - Kompakt Tablo Formatı */}
                  <Box sx={{ p: 0 }}>
                    {categoryQuestions.map(({ question, index: qIndex }) => {
                      const isAnswered = watch(`questions.${qIndex}.score`) !== '';
                      const score = watch(`questions.${qIndex}.score`);
                      
                      return (
                        <Box
                          key={question.id}
                          sx={{
                            borderBottom: '1px solid #e5e7eb',
                            p: 1.5,
                            bgcolor: isAnswered ? `${categoryColor.bg}10` : 'white',
                            '&:hover': { bgcolor: `${categoryColor.bg}20` },
                            '&:last-child': { borderBottom: 'none' },
                          }}
                        >
                          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                            {/* Soru Numarası */}
                            <Box
                              sx={{
                                minWidth: 24,
                                height: 24,
                                borderRadius: '4px',
                                bgcolor: categoryColor.bg,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexShrink: 0,
                                mt: 0.5,
                              }}
                            >
                              <Typography 
                                sx={{ 
                                  fontSize: '0.7rem', 
                                  fontWeight: 600,
                                  color: categoryColor.text,
                                }}
                              >
                                {qIndex + 1}
                              </Typography>
                            </Box>

                            {/* Soru Metni ve Kontroller */}
                            <Box sx={{ flex: 1, minWidth: 0 }}>
                              <Typography 
                                variant="body2" 
                                sx={{ 
                                  fontSize: '0.8rem', 
                                  fontWeight: 500, 
                                  mb: 1,
                                  color: '#374151',
                                }}
                              >
                                {question.text}
                              </Typography>

                              {/* Değerlendirme ve Görsel - Yan Yana */}
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
                                <Controller
                                  name={`questions.${qIndex}.score`}
                                  control={control}
                                  render={({ field }) => (
                                    <FormControl component="fieldset" error={!!errors.questions?.[qIndex]?.score} size="small">
                                      <RadioGroup 
                                        {...field} 
                                        row
                                        sx={{ gap: 0.5 }}
                                      >
                                        <FormControlLabel 
                                          value="dusuk" 
                                          control={<Radio size="small" sx={{ py: 0.5 }} />} 
                                          label={<Typography sx={{ fontSize: '0.7rem' }}>Düşük</Typography>}
                                          sx={{ m: 0, mr: 1 }}
                                        />
                                        <FormControlLabel 
                                          value="orta" 
                                          control={<Radio size="small" sx={{ py: 0.5 }} />} 
                                          label={<Typography sx={{ fontSize: '0.7rem' }}>Orta</Typography>}
                                          sx={{ m: 0, mr: 1 }}
                                        />
                                        <FormControlLabel 
                                          value="yuksek" 
                                          control={<Radio size="small" sx={{ py: 0.5 }} />} 
                                          label={<Typography sx={{ fontSize: '0.7rem' }}>Yüksek</Typography>}
                                          sx={{ m: 0 }}
                                        />
                                      </RadioGroup>
                                    </FormControl>
                                  )}
                                />

                                {/* Görsel Yükleme - Kompakt */}
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                  <input
                                    accept="image/*"
                                    style={{ display: 'none' }}
                                    id={`question-images-upload-${qIndex}`}
                                    type="file"
                                    multiple
                                    onChange={(e) => {
                                      if (e.target.files) {
                                        handleMultipleImageUpload(qIndex, e.target.files);
                                      }
                                    }}
                                  />
                                  <label htmlFor={`question-images-upload-${qIndex}`}>
                                    <IconButton
                                      component="span"
                                      size="small"
                                      sx={{ 
                                        p: 0.5,
                                        color: categoryColor.text,
                                        '&:hover': { bgcolor: categoryColor.bg },
                                      }}
                                    >
                                      <CloudUpload fontSize="small" />
                                    </IconButton>
                                  </label>
                                  {question.images && question.images.length > 0 && (
                                    <Chip
                                      label={question.images.length}
                                      size="small"
                                      sx={{ 
                                        fontSize: '0.65rem',
                                        height: 18,
                                        bgcolor: categoryColor.bg,
                                        color: categoryColor.text,
                                      }}
                                    />
                                  )}
                                  {isAnswered && (
                                    <Chip
                                      label={score === 'yuksek' ? 'Yüksek' : score === 'orta' ? 'Orta' : 'Düşük'}
                                      size="small"
                                      sx={{
                                        fontSize: '0.65rem',
                                        height: 18,
                                        bgcolor: score === 'yuksek' ? '#d1fae5' : score === 'orta' ? '#fef3c7' : '#fee2e2',
                                        color: score === 'yuksek' ? '#059669' : score === 'orta' ? '#d97706' : '#dc2626',
                                      }}
                                    />
                                  )}
                                </Box>
                              </Box>

                              {/* Aksiyon Planı - Kompakt */}
                              {(watch(`questions.${qIndex}.score`) === 'dusuk' || watch(`questions.${qIndex}.score`) === 'orta') && (
                                <Box 
                                  sx={{ 
                                    mt: 1.5, 
                                    p: 1.5, 
                                    bgcolor: '#fff7ed',
                                    border: '1px solid #fb923c',
                                    borderRadius: 1,
                                  }}
                                >
                                  <Typography variant="caption" sx={{ fontSize: '0.7rem', fontWeight: 600, color: '#ea580c', display: 'block', mb: 1 }}>
                                    ⚠️ Aksiyon Planı Gerekli
                                  </Typography>

                                  {question.actions && question.actions.length > 0 && (
                                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                                      {question.actions.map((action: ActionFormData, aIndex: number) => (
                                        <Box 
                                          key={aIndex} 
                                          sx={{ 
                                            p: 1.5,
                                            bgcolor: 'white',
                                            border: '1px solid #fb923c',
                                            borderRadius: 1,
                                          }}
                                        >
                                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                                            <Typography variant="caption" fontWeight={600} sx={{ fontSize: '0.75rem', color: '#ea580c' }}>
                                              Aksiyon #{aIndex + 1}
                                            </Typography>
                                            <IconButton 
                                              size="small" 
                                              onClick={() => handleRemoveAction(qIndex, aIndex)}
                                              sx={{ 
                                                p: 0.5,
                                                '&:hover': { bgcolor: '#fee2e2' },
                                              }}
                                            >
                                              <Delete fontSize="small" />
                                            </IconButton>
                                          </Box>
                            
                                          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 1 }}>
                                            <Controller
                                              name={`questions.${qIndex}.actions.${aIndex}.identified_non_conformity`}
                                              control={control}
                                              render={({ field }) => (
                                                <TextField
                                                  {...field}
                                                  fullWidth
                                                  size="small"
                                                  label="Uygunsuzluk"
                                                  multiline
                                                  rows={2}
                                                  error={!!errors.questions?.[qIndex]?.actions?.[aIndex]?.identified_non_conformity}
                                                  helperText={errors.questions?.[qIndex]?.actions?.[aIndex]?.identified_non_conformity?.message}
                                                />
                                              )}
                                            />
                                            <Controller
                                              name={`questions.${qIndex}.actions.${aIndex}.proposed_activity`}
                                              control={control}
                                              render={({ field }) => (
                                                <TextField
                                                  {...field}
                                                  fullWidth
                                                  size="small"
                                                  label="Önerilen"
                                                  multiline
                                                  rows={2}
                                                  error={!!errors.questions?.[qIndex]?.actions?.[aIndex]?.proposed_activity}
                                                  helperText={errors.questions?.[qIndex]?.actions?.[aIndex]?.proposed_activity?.message}
                                                />
                                              )}
                                            />
                                            <Controller
                                              name={`questions.${qIndex}.actions.${aIndex}.planned_activity`}
                                              control={control}
                                              render={({ field }) => (
                                                <TextField
                                                  {...field}
                                                  fullWidth
                                                  size="small"
                                                  label="Planlanan"
                                                  multiline
                                                  rows={2}
                                                  error={!!errors.questions?.[qIndex]?.actions?.[aIndex]?.planned_activity}
                                                  helperText={errors.questions?.[qIndex]?.actions?.[aIndex]?.planned_activity?.message}
                                                />
                                              )}
                                            />
                                            <Controller
                                              name={`questions.${qIndex}.actions.${aIndex}.target_date`}
                                              control={control}
                                              render={({ field }) => (
                                                <TextField
                                                  {...field}
                                                  label="Hedef Tarih"
                                                  type="date"
                                                  fullWidth
                                                  size="small"
                                                  InputLabelProps={{ shrink: true }}
                                                  error={!!errors.questions?.[qIndex]?.actions?.[aIndex]?.target_date}
                                                  helperText={errors.questions?.[qIndex]?.actions?.[aIndex]?.target_date?.message}
                                                />
                                              )}
                                            />
                                            <Controller
                                              name={`questions.${qIndex}.actions.${aIndex}.priority`}
                                              control={control}
                                              render={({ field }) => (
                                                <FormControl fullWidth error={!!errors.questions?.[qIndex]?.actions?.[aIndex]?.priority} size="small">
                                                  <InputLabel>Öncelik</InputLabel>
                                                  <Select {...field} label="Öncelik">
                                                    <MenuItem value="Düşük">Düşük</MenuItem>
                                                    <MenuItem value="Orta">Orta</MenuItem>
                                                    <MenuItem value="Yüksek">Yüksek</MenuItem>
                                                  </Select>
                                                </FormControl>
                                              )}
                                            />
                                          </Box>
                                        </Box>
                                      ))}
                                    </Box>
                                  )}
                                </Box>
                              )}
                            </Box>
                          </Box>
                        </Box>
                      );
                    })}
                  </Box>
                </Card>
              );
            })}
          </Box>
        );

      case 2:
        const { totalScore, maxScore, percentage } = calculateScore();
        return (
          <Card sx={{ p: 2 }}>
            <CardContent sx={{ p: 0 }}>
              <Typography variant="h6" gutterBottom sx={{ fontWeight: 600, fontSize: '1rem' }}>
                Denetim Özeti
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                <Box sx={{ flex: '1 1 300px' }}>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>Bölüm:</strong> {departments.find(d => d.id === watch('department_id'))?.name}
                  </Typography>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>Denetim Tarihi:</strong> {format(new Date(watch('audit_date')), 'dd/MM/yyyy')}
                  </Typography>
                </Box>
                <Box sx={{ flex: '1 1 300px' }}>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>Alan:</strong> {watch('area')}
                  </Typography>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>Denetleyen:</strong> {users.find(u => u.id === watch('auditor_id'))?.name}
                  </Typography>
                </Box>
                <Box sx={{ flex: '1 1 100%' }}>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="body2" sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>Toplam Puan:</strong> {totalScore} / {maxScore} (%{percentage.toFixed(2)})
                  </Typography>
                  <Typography variant="body2" sx={{ fontSize: '0.85rem' }}>
                    <strong>5S Seviyesi:</strong> {get5SLevel(percentage)}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        );

      default:
        return 'Bilinmeyen adım';
    }
  };

  if (loading && departments.length === 0) {
    return (
      <Box sx={{ textAlign: 'center', py: 4 }}>
        <CircularProgress sx={{ mb: 2 }} />
        <Typography variant="h6">Yükleniyor...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ m: 2 }}>{error}</Alert>
    );
  }

  return (
    <Box sx={{ maxWidth: '100%', mx: 'auto', p: 1 }}>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 700, mb: 3, fontSize: '1.5rem' }}>
        {plan ? `Denetim: ${plan.name}` : 'Yeni Denetim Oluştur'}
      </Typography>

      {/* Stepper - Sadece plan yoksa göster */}
      {!plan && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Stepper activeStep={activeStep} alternativeLabel>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </CardContent>
        </Card>
      )}

      {/* Content */}
      <Box sx={{ mb: 2 }}>
        {getStepContent(activeStep)}
      </Box>

      {/* Navigation */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Button
          disabled={activeStep === 0}
          onClick={handleBack}
          startIcon={<ArrowBack fontSize="small" />}
          size="small"
        >
          Geri
        </Button>
        {activeStep === steps.length - 1 ? (
          <Box>
            <Button
              variant="outlined"
              color="secondary"
              onClick={() => handleSubmit((data) => onSubmit(data, 'draft'))()}
              startIcon={<Save />}
              sx={{ mr: 1, fontSize: '0.8rem' }}
              disabled={loading}
            >
              Taslak Kaydet
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleSubmit((data) => onSubmit(data, 'published'))()}
              startIcon={<Publish />}
              sx={{ fontSize: '0.8rem' }}
              disabled={loading}
            >
              Denetimi Yayınla
            </Button>
          </Box>
        ) : (
          <Button
            onClick={handleNext}
            endIcon={<ArrowForward fontSize="small" />}
            variant="contained"
            size="small"
          >
            İleri
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default NewAuditPage;